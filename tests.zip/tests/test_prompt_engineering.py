"""
Tests for Prompt Engineering Module
"""

import pytest
from src.prompt_engineering import PromptTemplate, PromptEngineer


class TestPromptTemplate:
    """Test PromptTemplate"""
    
    def test_function_completion_template(self):
        """Test function completion template"""
        template = PromptTemplate.for_function_completion("python")
        
        assert template.language == "python"
        assert "python function" in template.template.lower()
        
        formatted = template.format(context="def my_func():")
        assert "my_func" in formatted
    
    def test_test_generation_template(self):
        """Test generation template"""
        template = PromptTemplate.for_test_generation("pytest")
        
        assert "pytest" in template.template.lower()
        
        code = "def add(a, b): return a + b"
        formatted = template.format(code=code)
        assert code in formatted
    
    def test_refactoring_templates(self):
        """Test refactoring templates"""
        types = ["improve_readability", "optimize_performance", "reduce_complexity"]
        
        for reftype in types:
            template = PromptTemplate.for_refactoring(reftype)
            assert template.description is not None
    
    def test_custom_template(self):
        """Test custom template"""
        template = PromptTemplate.for_custom(
            "Custom: {input}",
            "My custom template"
        )
        
        assert template.format(input="test") == "Custom: test"


class TestPromptEngineer:
    """Test PromptEngineer"""
    
    def test_chain_of_thought(self):
        """Test chain of thought prompt"""
        prompt = PromptEngineer.chain_of_thought(
            "What is 2+2?",
            "Mathematics"
        )
        
        assert "step by step" in prompt.lower()
        assert "2+2" in prompt
    
    def test_few_shot_prompt(self):
        """Test few-shot prompt"""
        examples = [
            "Example 1: Input A -> Output A",
            "Example 2: Input B -> Output B"
        ]
        
        prompt = PromptEngineer.few_shot_prompt(
            examples,
            "Query: Input C",
            "Task: Map inputs"
        )
        
        assert "Example 1" in prompt
        assert "Input C" in prompt
    
    def test_role_based_prompt(self):
        """Test role-based prompt"""
        prompt = PromptEngineer.role_based_prompt(
            "senior developer",
            "Review this code",
            "Context: Python code"
        )
        
        assert "senior developer" in prompt
        assert "Review this code" in prompt


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
