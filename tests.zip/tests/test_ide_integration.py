"""
Tests for IDE Integration Module
"""

import pytest
import json
from src.ide_integration import (
    VSCodeIntegration,
    ExtensionManifest,
    LanguageServerProtocol
)


class TestVSCodeIntegration:
    """Test VS Code integration"""
    
    def test_generate_code_action(self):
        """Test code action generation"""
        vscode = VSCodeIntegration()
        
        action = vscode.generate_code_action(
            title="Refactor Code",
            code="x = 1",
            action_type="improve_readability"
        )
        
        assert action["title"] == "Refactor Code"
        assert "refactor" in action["kind"]
    
    def test_generate_completion_item(self):
        """Test completion item generation"""
        vscode = VSCodeIntegration()
        
        item = vscode.generate_completion_item(
            label="function_name",
            kind="Function",
            detail="A test function",
            documentation="This is a test",
            insert_text="function_name($0)"
        )
        
        assert item["label"] == "function_name"
        assert item["insertText"] == "function_name($0)"


class TestExtensionManifest:
    """Test extension manifest generation"""
    
    def test_generate_manifest(self):
        """Test manifest generation"""
        manifest = ExtensionManifest.generate(
            name="test-extension",
            description="Test extension"
        )
        
        assert manifest["name"] == "test-extension"
        assert "vscode" in manifest["engines"]
    
    def test_manifest_commands(self):
        """Test manifest with commands"""
        commands = [
            {"command": "test.cmd1", "title": "Command 1"}
        ]
        
        manifest = ExtensionManifest.generate(
            name="test",
            description="Test",
            commands=commands
        )
        
        assert len(manifest["contributes"]["commands"]) == 1


class TestLanguageServerProtocol:
    """Test LSP utilities"""
    
    def test_diagnostic(self):
        """Test diagnostic creation"""
        diag = LanguageServerProtocol.diagnostic(
            line=0,
            start_char=5,
            end_char=10,
            message="Error"
        )
        
        assert diag["range"]["start"]["line"] == 0
        assert diag["message"] == "Error"
    
    def test_hover_info(self):
        """Test hover info"""
        hover = LanguageServerProtocol.hover_info(
            "def test(): pass",
            language="python"
        )
        
        assert "contents" in hover
        assert hover["contents"]["language"] == "python"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
