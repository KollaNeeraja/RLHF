"""
Tests for DSL Module
"""

import pytest
import json
from src.dsl import (
    CodeBlock, 
    TestCase,
    FunctionSignature,
    StructuredCodeDSL,
    SchemaValidator
)


class TestCodeBlock:
    """Test CodeBlock"""
    
    def test_code_block_creation(self):
        """Test creating code block"""
        block = CodeBlock(
            language="python",
            code="print('hello')",
            description="Hello world"
        )
        
        assert block.language == "python"
        assert block.code == "print('hello')"
        assert block.description == "Hello world"
    
    def test_code_block_to_dict(self):
        """Test code block to dict conversion"""
        block = CodeBlock(
            language="python",
            code="x = 1",
            imports=["typing"]
        )
        
        block_dict = block.to_dict()
        assert block_dict["language"] == "python"
        assert "typing" in block_dict["imports"]


class TestTestCase:
    """Test TestCase"""
    
    def test_test_case_creation(self):
        """Test creating test case"""
        test = TestCase(
            name="test_add",
            description="Test addition",
            input_data={"a": 2, "b": 3},
            expected_output=5
        )
        
        assert test.name == "test_add"
        assert test.expected_output == 5


class TestFunctionSignature:
    """Test FunctionSignature"""
    
    def test_signature_creation(self):
        """Test creating function signature"""
        sig = FunctionSignature(
            name="calculate",
            parameters={"x": "int", "y": "int"},
            return_type="int",
            docstring="Add two numbers"
        )
        
        assert sig.name == "calculate"
        assert len(sig.parameters) == 2


class TestStructuredCodeDSL:
    """Test StructuredCodeDSL"""
    
    def test_generate_function(self):
        """Test function generation"""
        sig = FunctionSignature(
            name="test_func",
            parameters={},
            return_type="str"
        )
        
        block = StructuredCodeDSL.generate_function(
            sig,
            "return 'hello'"
        )
        
        assert block.language == "python"
        assert "hello" in block.code
    
    def test_to_json(self):
        """Test JSON conversion"""
        block = CodeBlock(
            language="python",
            code="x = 1"
        )
        
        json_str = StructuredCodeDSL.to_json(block)
        data = json.loads(json_str)
        
        assert data["language"] == "python"
        assert data["code"] == "x = 1"


class TestSchemaValidator:
    """Test SchemaValidator"""
    
    def test_validate_code_block(self):
        """Test code block validation"""
        valid = {"language": "python", "code": "x = 1"}
        assert SchemaValidator.validate_code_block(valid)
        
        invalid = {"language": "python"}
        assert not SchemaValidator.validate_code_block(invalid)
    
    def test_validate_test_case(self):
        """Test case validation"""
        valid = {
            "name": "test",
            "description": "Test",
            "input_data": {},
            "expected_output": None
        }
        assert SchemaValidator.validate_test_case(valid)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
