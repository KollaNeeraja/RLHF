"""
Tests for Models Module
"""

import pytest
from src.models import CodeTransformer, ModelConfig, ModelType


class TestModelConfig:
    """Test ModelConfig"""
    
    def test_model_config_creation(self):
        """Test creating ModelConfig"""
        config = ModelConfig(
            model_name="starcoder",
            max_length=1024,
            temperature=0.8
        )
        
        assert config.model_name == "starcoder"
        assert config.max_length == 1024
        assert config.temperature == 0.8
    
    def test_model_config_defaults(self):
        """Test ModelConfig default values"""
        config = ModelConfig(model_name="test")
        
        assert config.max_length == 2048
        assert config.temperature == 0.7
        assert config.top_p == 0.95


class TestCodeTransformer:
    """Test CodeTransformer"""
    
    def test_get_model_id(self):
        """Test model ID resolution"""
        transformer = CodeTransformer.__new__(CodeTransformer)
        
        model_id = transformer._get_model_id("StarCoder")
        assert model_id == "bigcode/starcoder"
        
        model_id = transformer._get_model_id("Code LLaMA")
        assert model_id == "meta-llama/CodeLlama-7b"
    
    @pytest.mark.skip(reason="Requires actual model download")
    def test_transformer_initialization(self):
        """Test CodeTransformer initialization"""
        config = ModelConfig(model_name="starcoder", device="cpu")
        transformer = CodeTransformer("StarCoder", config=config)
        
        assert transformer.model is not None
        assert transformer.tokenizer is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
