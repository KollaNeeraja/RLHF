"""
Code Generation Pipelines
"""

from typing import Optional, List, Dict, Any
from src.models import CodeTransformer
from src.prompt_engineering import PromptTemplate


class CodeGenerator:
    """Main code generation pipeline"""
    
    def __init__(self, model: CodeTransformer):
        """
        Initialize CodeGenerator
        
        Args:
            model: CodeTransformer instance
        """
        self.model = model
    
    def complete_function(
        self,
        context: str,
        max_tokens: int = 256,
        language: str = "python"
    ) -> str:
        """
        Complete a code function
        
        Args:
            context: Partial function code
            max_tokens: Maximum tokens to generate
            language: Programming language
            
        Returns:
            Completed function code
        """
        template = PromptTemplate.for_function_completion(language)
        prompt = template.format(context=context)
        
        generated = self.model.generate(prompt, max_length=max_tokens)
        return generated
    
    def generate_tests(
        self,
        code: str,
        test_framework: str = "pytest",
        max_tokens: int = 512
    ) -> str:
        """
        Generate tests for given code
        
        Args:
            code: Source code to test
            test_framework: Testing framework to use
            max_tokens: Maximum tokens to generate
            
        Returns:
            Generated test code
        """
        template = PromptTemplate.for_test_generation(test_framework)
        prompt = template.format(code=code)
        
        generated = self.model.generate(prompt, max_length=max_tokens)
        return generated
    
    def refactor_code(
        self,
        code: str,
        refactoring_type: str = "improve_readability",
        max_tokens: int = 512
    ) -> str:
        """
        Refactor code
        
        Args:
            code: Source code to refactor
            refactoring_type: Type of refactoring
            max_tokens: Maximum tokens to generate
            
        Returns:
            Refactored code
        """
        template = PromptTemplate.for_refactoring(refactoring_type)
        prompt = template.format(code=code)
        
        generated = self.model.generate(prompt, max_length=max_tokens)
        return generated
    
    def fix_bugs(
        self,
        code: str,
        error_message: Optional[str] = None,
        max_tokens: int = 512
    ) -> str:
        """
        Fix bugs in code
        
        Args:
            code: Buggy code
            error_message: Error message or description
            max_tokens: Maximum tokens to generate
            
        Returns:
            Fixed code
        """
        template = PromptTemplate.for_bug_fixing()
        prompt = template.format(code=code, error=error_message or "")
        
        generated = self.model.generate(prompt, max_length=max_tokens)
        return generated


__all__ = ["CodeGenerator"]
