"""
Code Refactoring Module
"""

from typing import Dict, Any, Optional, List
from enum import Enum
from src.models import CodeTransformer


class RefactoringStrategy(Enum):
    """Available refactoring strategies"""
    IMPROVE_READABILITY = "improve_readability"
    OPTIMIZE_PERFORMANCE = "optimize_performance"
    REDUCE_COMPLEXITY = "reduce_complexity"
    ADD_DOCUMENTATION = "add_documentation"
    MODERNIZE_SYNTAX = "modernize_syntax"
    EXTRACT_METHODS = "extract_methods"


class CodeRefactorer:
    """Code refactoring engine"""
    
    def __init__(self, model: CodeTransformer):
        """
        Initialize CodeRefactorer
        
        Args:
            model: CodeTransformer instance
        """
        self.model = model
    
    def refactor(
        self,
        code: str,
        strategy: RefactoringStrategy = RefactoringStrategy.IMPROVE_READABILITY,
        max_tokens: int = 512,
        **kwargs
    ) -> str:
        """
        Refactor code with specified strategy
        
        Args:
            code: Source code
            strategy: Refactoring strategy
            max_tokens: Maximum tokens to generate
            **kwargs: Additional parameters
            
        Returns:
            Refactored code
        """
        prompt = self._build_refactoring_prompt(code, strategy, **kwargs)
        return self.model.generate(prompt, max_length=max_tokens)
    
    def _build_refactoring_prompt(
        self,
        code: str,
        strategy: RefactoringStrategy,
        **kwargs
    ) -> str:
        """Build refactoring prompt"""
        strategy_prompts = {
            RefactoringStrategy.IMPROVE_READABILITY: self._prompt_readability,
            RefactoringStrategy.OPTIMIZE_PERFORMANCE: self._prompt_performance,
            RefactoringStrategy.REDUCE_COMPLEXITY: self._prompt_complexity,
            RefactoringStrategy.ADD_DOCUMENTATION: self._prompt_documentation,
            RefactoringStrategy.MODERNIZE_SYNTAX: self._prompt_modernize,
            RefactoringStrategy.EXTRACT_METHODS: self._prompt_extract_methods,
        }
        
        prompt_builder = strategy_prompts.get(strategy)
        return prompt_builder(code, **kwargs) if prompt_builder else ""
    
    @staticmethod
    def _prompt_readability(code: str, **kwargs) -> str:
        return f"""Refactor the following code to improve readability:
        
{code}

Refactored code with better naming and structure:
"""
    
    @staticmethod
    def _prompt_performance(code: str, **kwargs) -> str:
        return f"""Optimize the following code for performance:
        
{code}

Optimized code:
"""
    
    @staticmethod
    def _prompt_complexity(code: str, **kwargs) -> str:
        return f"""Reduce the complexity of the following code:
        
{code}

Simplified code:
"""
    
    @staticmethod
    def _prompt_documentation(code: str, **kwargs) -> str:
        return f"""Add comprehensive documentation to the following code:
        
{code}

Documented code:
"""
    
    @staticmethod
    def _prompt_modernize(code: str, **kwargs) -> str:
        language = kwargs.get('language', 'python')
        return f"""Modernize the following {language} code:
        
{code}

Modernized code:
"""
    
    @staticmethod
    def _prompt_extract_methods(code: str, **kwargs) -> str:
        return f"""Extract helper methods from the following code:
        
{code}

Refactored code with extracted methods:
"""


__all__ = [
    "CodeRefactorer",
    "RefactoringStrategy",
]
