"""
IDE Integration Module (VS Code and others)
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass
import json


@dataclass
class VSCodeCommand:
    """VS Code command structure"""
    command: str
    title: str
    category: str = "CodePOC"
    args: List[Any] = None


@dataclass
class CodeAction:
    """VS Code code action"""
    title: str
    kind: str  # e.g., 'refactor', 'fix'
    command: str
    range: Optional[Dict[str, int]] = None
    diagnostics: List[Dict[str, Any]] = None


class IDEIntegration:
    """Base IDE integration"""
    
    def __init__(self, ide_name: str):
        self.ide_name = ide_name
    
    def generate_code_action(
        self,
        title: str,
        code: str,
        action_type: str = "refactor"
    ) -> Dict[str, Any]:
        """Generate code action"""
        raise NotImplementedError


class VSCodeIntegration(IDEIntegration):
    """VS Code specific integration"""
    
    def __init__(self):
        super().__init__("VS Code")
    
    def generate_code_action(
        self,
        title: str,
        code: str,
        action_type: str = "refactor",
        language: str = "python"
    ) -> Dict[str, Any]:
        """Generate VS Code code action"""
        return {
            "title": title,
            "kind": f"refactor.{action_type}",
            "command": {
                "title": title,
                "command": "code-poc.action",
                "arguments": [code, action_type, language]
            }
        }
    
    def generate_hover_provider(
        self,
        code: str,
        documentation: str
    ) -> Dict[str, Any]:
        """Generate hover information"""
        return {
            "contents": {
                "language": "python",
                "value": code
            },
            "range": None
        }
    
    def generate_completion_item(
        self,
        label: str,
        kind: str,
        detail: str,
        documentation: str,
        insert_text: str
    ) -> Dict[str, Any]:
        """Generate completion item"""
        return {
            "label": label,
            "kind": kind,
            "detail": detail,
            "documentation": documentation,
            "insertText": insert_text,
            "insertTextFormat": 2  # Snippet format
        }


class ExtensionManifest:
    """VS Code extension manifest generator"""
    
    @staticmethod
    def generate(
        name: str,
        description: str,
        version: str = "0.1.0",
        commands: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """Generate package.json manifest"""
        return {
            "name": name,
            "displayName": name,
            "description": description,
            "version": version,
            "engines": {
                "vscode": "^1.73.0"
            },
            "categories": [
                "Programming Languages",
                "Code Generators",
                "Refactoring"
            ],
            "contributes": {
                "commands": commands or [],
                "keybindings": [
                    {
                        "command": "code-poc.generateTests",
                        "key": "ctrl+shift+t",
                        "mac": "cmd+shift+t",
                        "when": "editorTextFocus"
                    },
                    {
                        "command": "code-poc.refactorCode",
                        "key": "ctrl+shift+r",
                        "mac": "cmd+shift+r",
                        "when": "editorTextFocus"
                    },
                    {
                        "command": "code-poc.fixBugs",
                        "key": "ctrl+shift+b",
                        "mac": "cmd+shift+b",
                        "when": "editorTextFocus"
                    }
                ]
            },
            "activationEvents": [
                "onLanguage:python",
                "onLanguage:javascript",
                "onLanguage:typescript"
            ],
            "main": "./src/extension.js"
        }


class LanguageServerProtocol:
    """Language Server Protocol integration"""
    
    @staticmethod
    def diagnostic(
        line: int,
        start_char: int,
        end_char: int,
        message: str,
        severity: int = 1  # Error
    ) -> Dict[str, Any]:
        """Create LSP diagnostic"""
        return {
            "range": {
                "start": {"line": line, "character": start_char},
                "end": {"line": line, "character": end_char}
            },
            "severity": severity,
            "message": message
        }
    
    @staticmethod
    def hover_info(
        content: str,
        language: str = "python"
    ) -> Dict[str, Any]:
        """Create LSP hover info"""
        return {
            "contents": {
                "language": language,
                "value": content
            }
        }


__all__ = [
    "IDEIntegration",
    "VSCodeIntegration",
    "ExtensionManifest",
    "LanguageServerProtocol",
    "VSCodeCommand",
    "CodeAction",
]
