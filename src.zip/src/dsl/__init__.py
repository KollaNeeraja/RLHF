"""
Domain-Specific Languages (DSL) for Structured Coding Outputs
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from enum import Enum
import json


class OutputFormat(Enum):
    """Supported output formats for DSLs"""
    JSON = "json"
    YAML = "yaml"
    XML = "xml"
    PYTHON = "python"


@dataclass
class CodeBlock:
    """Structured code block"""
    language: str
    code: str
    description: Optional[str] = None
    imports: List[str] = None
    
    def __post_init__(self):
        if self.imports is None:
            self.imports = []
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TestCase:
    """Structured test case"""
    name: str
    description: str
    input_data: Dict[str, Any]
    expected_output: Any
    test_framework: str = "pytest"
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class FunctionSignature:
    """Structured function signature"""
    name: str
    parameters: Dict[str, str]  # name -> type
    return_type: str
    docstring: Optional[str] = None
    decorators: List[str] = None
    
    def __post_init__(self):
        if self.decorators is None:
            self.decorators = []
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class StructuredCodeDSL:
    """DSL for generating structured code outputs"""
    
    @staticmethod
    def generate_function(
        signature: FunctionSignature,
        implementation: str,
        language: str = "python"
    ) -> CodeBlock:
        """Generate structured function"""
        return CodeBlock(
            language=language,
            code=implementation,
            description=signature.docstring,
            imports=[]
        )
    
    @staticmethod
    def generate_test_suite(
        function_name: str,
        test_cases: List[TestCase]
    ) -> CodeBlock:
        """Generate test suite"""
        test_code = f"""
# Test suite for {function_name}
import pytest

"""
        for test in test_cases:
            test_code += f"""
def test_{test.name}():
    \"\"\"
    {test.description}
    \"\"\"
    input_data = {test.input_data}
    expected = {test.expected_output}
    result = {function_name}(**input_data)
    assert result == expected
"""
        
        return CodeBlock(
            language="python",
            code=test_code,
            description=f"Test suite for {function_name}"
        )
    
    @staticmethod
    def to_json(obj: Any) -> str:
        """Convert to JSON"""
        if hasattr(obj, 'to_dict'):
            return json.dumps(obj.to_dict(), indent=2)
        return json.dumps(obj, indent=2)
    
    @staticmethod
    def from_json(json_str: str, target_type) -> Any:
        """Parse from JSON"""
        data = json.loads(json_str)
        if target_type == CodeBlock:
            return CodeBlock(**data)
        elif target_type == TestCase:
            return TestCase(**data)
        elif target_type == FunctionSignature:
            return FunctionSignature(**data)
        return data


class SchemaValidator:
    """Validate output schemas"""
    
    @staticmethod
    def validate_code_block(data: Dict[str, Any]) -> bool:
        """Validate code block schema"""
        required = {'language', 'code'}
        return required.issubset(set(data.keys()))
    
    @staticmethod
    def validate_test_case(data: Dict[str, Any]) -> bool:
        """Validate test case schema"""
        required = {'name', 'description', 'input_data', 'expected_output'}
        return required.issubset(set(data.keys()))
    
    @staticmethod
    def validate_function_signature(data: Dict[str, Any]) -> bool:
        """Validate function signature schema"""
        required = {'name', 'parameters', 'return_type'}
        return required.issubset(set(data.keys()))


__all__ = [
    "CodeBlock",
    "TestCase",
    "FunctionSignature",
    "StructuredCodeDSL",
    "SchemaValidator",
    "OutputFormat",
]
