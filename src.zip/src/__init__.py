"""
Transformer Models for Code - POC Package
Main module for code generation and analysis using transformer models.
"""

__version__ = "0.1.0"
__author__ = "Code POC Team"

from src.models import CodeTransformer
from src.generators import CodeGenerator

__all__ = [
    "CodeTransformer",
    "CodeGenerator",
]
