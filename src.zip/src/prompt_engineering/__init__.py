"""
Prompt Engineering Utilities and Templates
"""

from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum


class LanguageTemplate(Enum):
    """Programming language templates"""
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    JAVA = "java"
    CSHARP = "csharp"
    GOLANG = "go"
    RUST = "rust"


@dataclass
class PromptTemplate:
    """Prompt template for code generation tasks"""
    
    template: str
    description: str
    language: str = "python"
    
    def format(self, **kwargs) -> str:
        """Format template with variables"""
        return self.template.format(**kwargs)
    
    @staticmethod
    def for_function_completion(language: str = "python") -> "PromptTemplate":
        """Create prompt for function completion"""
        templates = {
            "python": """Complete the following Python function:

{context}

# Complete implementation:
def """,
            "javascript": """Complete the following JavaScript function:

{context}

// Complete implementation:
function """,
            "java": """Complete the following Java method:

{context}

// Complete implementation
public """,
        }
        
        template = templates.get(language, templates["python"])
        return PromptTemplate(
            template=template,
            description="Function completion prompt",
            language=language
        )
    
    @staticmethod
    def for_test_generation(framework: str = "pytest") -> "PromptTemplate":
        """Create prompt for test generation"""
        templates = {
            "pytest": """Generate comprehensive pytest test cases for the following function:

{code}

# Test cases:
import pytest

def test_""",
            "unittest": """Generate comprehensive unittest test cases for the following function:

{code}

# Test cases:
import unittest

class Test""",
            "jest": """Generate comprehensive Jest test cases for the following function:

{code}

// Test cases:
describe('""",
        }
        
        template = templates.get(framework, templates["pytest"])
        return PromptTemplate(
            template=template,
            description="Test generation prompt",
            language="python" if framework in ["pytest", "unittest"] else "javascript"
        )
    
    @staticmethod
    def for_refactoring(refactoring_type: str = "improve_readability") -> "PromptTemplate":
        """Create prompt for code refactoring"""
        templates = {
            "improve_readability": """Refactor the following code to improve readability and maintainability:

{code}

# Refactored code:
""",
            "optimize_performance": """Optimize the following code for better performance:

{code}

# Optimized code:
""",
            "reduce_complexity": """Simplify the following code to reduce complexity:

{code}

# Simplified code:
""",
            "add_documentation": """Add comprehensive documentation to the following code:

{code}

# Documented code:
""",
        }
        
        template = templates.get(refactoring_type, templates["improve_readability"])
        return PromptTemplate(
            template=template,
            description=f"Refactoring prompt ({refactoring_type})"
        )
    
    @staticmethod
    def for_bug_fixing() -> "PromptTemplate":
        """Create prompt for bug fixing"""
        return PromptTemplate(
            template="""Fix the bugs in the following code:

Code:
{code}

Error message (if available):
{error}

# Fixed code:
""",
            description="Bug fixing prompt"
        )
    
    @staticmethod
    def for_code_review() -> "PromptTemplate":
        """Create prompt for code review"""
        return PromptTemplate(
            template="""Review the following code and provide feedback:

{code}

# Code review:
- Issues found:
- Suggestions:
- Best practices:
""",
            description="Code review prompt"
        )
    
    @staticmethod
    def for_documentation() -> "PromptTemplate":
        """Create prompt for documentation generation"""
        return PromptTemplate(
            template="""Generate clear and concise documentation for the following code:

{code}

# Documentation:
""",
            description="Documentation generation prompt"
        )
    
    @staticmethod
    def for_custom(template_str: str, description: str = "") -> "PromptTemplate":
        """Create custom prompt template"""
        return PromptTemplate(
            template=template_str,
            description=description or "Custom prompt"
        )


class PromptEngineer:
    """Advanced prompt engineering utilities"""
    
    @staticmethod
    def chain_of_thought(query: str, context: str = "") -> str:
        """Generate chain-of-thought prompt"""
        return f"""Solve this step by step:

Context: {context}

Query: {query}

Let's think about this step by step:
1. """
    
    @staticmethod
    def few_shot_prompt(
        examples: list,
        query: str,
        task_description: str = ""
    ) -> str:
        """Generate few-shot prompt with examples"""
        prompt = f"{task_description}\n\n" if task_description else ""
        prompt += "Examples:\n\n"
        
        for i, example in enumerate(examples, 1):
            prompt += f"Example {i}:\n{example}\n\n"
        
        prompt += f"Now solve:\n{query}\n\nSolution:"
        return prompt
    
    @staticmethod
    def role_based_prompt(
        role: str,
        task: str,
        context: str = ""
    ) -> str:
        """Generate role-based prompt"""
        return f"""You are a {role}.

Context:
{context}

Task:
{task}

Response:"""


__all__ = [
    "PromptTemplate",
    "PromptEngineer",
    "LanguageTemplate",
]
