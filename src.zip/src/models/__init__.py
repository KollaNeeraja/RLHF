"""
Transformer Model Wrappers and Configuration
"""

from enum import Enum
from typing import Optional, Dict, Any
from dataclasses import dataclass
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM


class ModelType(Enum):
    """Supported transformer models for code"""
    CODEX = "openai/codex"
    STARCODER = "bigcode/starcoder"
    CODE_LLAMA = "meta-llama/CodeLlama-7b"
    DEEPSEEK = "deepseek-ai/deepseek-coder-7b-base"


@dataclass
class ModelConfig:
    """Configuration for transformer models"""
    model_name: str
    max_length: int = 2048
    temperature: float = 0.7
    top_p: float = 0.95
    top_k: int = 50
    num_return_sequences: int = 1
    use_cache: bool = True
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


class CodeTransformer:
    """Wrapper for transformer models for code generation"""
    
    def __init__(
        self,
        model_name: str,
        config: Optional[ModelConfig] = None,
        model_path: Optional[str] = None
    ):
        """
        Initialize CodeTransformer
        
        Args:
            model_name: Name of the model (e.g., 'StarCoder')
            config: ModelConfig instance
            model_path: Path to custom model weights
        """
        self.model_name = model_name
        self.config = config or ModelConfig(model_name=model_name)
        self.device = self.config.device
        
        self._load_model(model_path)
    
    def _load_model(self, model_path: Optional[str] = None):
        """Load tokenizer and model"""
        try:
            # Try to load from HuggingFace
            model_id = self._get_model_id(self.model_name)
            self.tokenizer = AutoTokenizer.from_pretrained(model_id)
            self.model = AutoModelForCausalLM.from_pretrained(
                model_id,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                device_map="auto" if self.device == "cuda" else None
            )
            
            if self.device == "cpu":
                self.model = self.model.to(self.device)
                
            self.model.eval()
        except Exception as e:
            raise ValueError(f"Failed to load model {self.model_name}: {str(e)}")
    
    def _get_model_id(self, model_name: str) -> str:
        """Get HuggingFace model ID from model name"""
        model_map = {
            "StarCoder": "bigcode/starcoder",
            "Code LLaMA": "meta-llama/CodeLlama-7b",
            "DeepSeek": "deepseek-ai/deepseek-coder-7b-base",
        }
        return model_map.get(model_name, model_name)
    
    def generate(
        self,
        prompt: str,
        max_length: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        **kwargs
    ) -> str:
        """
        Generate code based on prompt
        
        Args:
            prompt: Input code prompt
            max_length: Maximum length of generated text
            temperature: Sampling temperature
            top_p: Nucleus sampling parameter
            **kwargs: Additional generation parameters
            
        Returns:
            Generated code string
        """
        max_length = max_length or self.config.max_length
        temperature = temperature or self.config.temperature
        top_p = top_p or self.config.top_p
        
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                temperature=temperature,
                top_p=top_p,
                top_k=self.config.top_k,
                num_return_sequences=self.config.num_return_sequences,
                use_cache=self.config.use_cache,
                **kwargs
            )
        
        generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return generated_text
    
    def to(self, device: str):
        """Move model to device"""
        self.device = device
        self.model = self.model.to(device)
        return self


__all__ = [
    "CodeTransformer",
    "ModelConfig",
    "ModelType",
]
