"""
AI Agents for Code Tasks
"""

from typing import Optional, Dict, Any, List
from enum import Enum
from src.models import CodeTransformer
from src.generators import CodeGenerator
from src.refactoring import CodeRefactorer


class AgentTask(Enum):
    """Available agent tasks"""
    CODE_GENERATION = "code_generation"
    TEST_GENERATION = "test_generation"
    REFACTORING = "refactoring"
    BUG_FIXING = "bug_fixing"
    CODE_REVIEW = "code_review"
    OPTIMIZATION = "optimization"


class CodeAgent:
    """Intelligent agent for code-related tasks"""
    
    def __init__(self, model: CodeTransformer):
        """
        Initialize CodeAgent
        
        Args:
            model: CodeTransformer instance
        """
        self.model = model
        self.generator = CodeGenerator(model)
        self.refactorer = CodeRefactorer(model)
        self.history: List[Dict[str, Any]] = []
    
    def execute(
        self,
        task: AgentTask,
        input_code: str,
        context: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        Execute agent task
        
        Args:
            task: Task to execute
            input_code: Input code
            context: Additional context
            **kwargs: Task-specific parameters
            
        Returns:
            Agent output
        """
        self._log_interaction(task, input_code, context)
        
        task_handlers = {
            AgentTask.CODE_GENERATION: self.generator.complete_function,
            AgentTask.TEST_GENERATION: self.generator.generate_tests,
            AgentTask.REFACTORING: self.refactorer.refactor,
            AgentTask.BUG_FIXING: self.generator.fix_bugs,
            AgentTask.CODE_REVIEW: self._review_code,
            AgentTask.OPTIMIZATION: self._optimize_code,
        }
        
        handler = task_handlers.get(task)
        if handler is None:
            raise ValueError(f"Unknown task: {task}")
        
        return handler(input_code, **kwargs)
    
    def _review_code(self, code: str, **kwargs) -> str:
        """Review code"""
        prompt = f"""Perform a comprehensive code review of the following code:

{code}

Code review (list issues, improvements, and suggestions):
"""
        return self.model.generate(prompt, max_length=512)
    
    def _optimize_code(self, code: str, **kwargs) -> str:
        """Optimize code"""
        optimization_type = kwargs.get('optimization_type', 'performance')
        prompt = f"""Optimize the following code for {optimization_type}:

{code}

Optimized code:
"""
        return self.model.generate(prompt, max_length=512)
    
    def _log_interaction(
        self,
        task: AgentTask,
        input_code: str,
        context: Optional[str]
    ):
        """Log interaction for history tracking"""
        self.history.append({
            "task": task.value,
            "input": input_code,
            "context": context,
            "timestamp": None  # Can add timestamp if needed
        })
    
    def get_history(self) -> List[Dict[str, Any]]:
        """Get interaction history"""
        return self.history.copy()
    
    def clear_history(self):
        """Clear interaction history"""
        self.history.clear()


class MultiAgentOrchestrator:
    """Orchestrate multiple agents for complex tasks"""
    
    def __init__(self, model: CodeTransformer):
        """
        Initialize MultiAgentOrchestrator
        
        Args:
            model: CodeTransformer instance
        """
        self.model = model
        self.agents: Dict[str, CodeAgent] = {
            "generator": CodeAgent(model),
            "refactorer": CodeAgent(model),
            "reviewer": CodeAgent(model),
        }
    
    def pipeline(
        self,
        code: str,
        tasks: List[AgentTask],
        **kwargs
    ) -> Dict[str, str]:
        """
        Execute pipeline of tasks
        
        Args:
            code: Input code
            tasks: List of tasks to execute
            **kwargs: Task parameters
            
        Returns:
            Dictionary of task results
        """
        results = {}
        current_code = code
        
        for task in tasks:
            agent = self.agents.get("generator")
            result = agent.execute(task, current_code, **kwargs)
            results[task.value] = result
            current_code = result  # Use output as input for next task
        
        return results


__all__ = [
    "CodeAgent",
    "MultiAgentOrchestrator",
    "AgentTask",
]
